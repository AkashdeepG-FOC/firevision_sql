import json
import os
import hashlib
from datetime import datetime
from typing import Dict, List, Optional
import requests

class ConfigManager:
    """Manages persistent configuration for the surveillance system"""
    
    BACKEND_URL = "http://localhost:5000/api/config"  # Adjust as needed
    
    def __init__(self, config_dir="config"):
        self.config_dir = config_dir
        self.config_file = os.path.join(config_dir, "app_config.json")
        self.cameras_file = os.path.join(config_dir, "cameras.json")
        self.users_file = os.path.join(config_dir, "users.json")
        self.streams_file = os.path.join(config_dir, "active_streams.json")
        
        # Create config directory if it doesn't exist
        if not os.path.exists(config_dir):
            os.makedirs(config_dir)
        
        # Initialize default configurations
        self.init_default_configs()
    
    def init_default_configs(self):
        """Initialize default configuration files if they don't exist"""
        
        # Default app config
        if not os.path.exists(self.config_file):
            default_config = {
                "app_settings": {
                    "auto_start_cameras": True,
                    "auto_start_streaming": True,
                    "remember_login": True,
                    "detection_confidence": 0.5,
                    "stream_quality": 75,
                    "stream_fps": 15,
                    "recording_format": "mp4",
                    "auto_upload_to_drive": False
                },
                "server_settings": {
                    "stream_server_url": "http://localhost:3000",
                    "auto_start_server": True
                },
                "last_login": {
                    "username": "",
                    "remember": False,
                    "login_time": ""
                }
            }
            self.save_config(default_config)
        
        # Default users file
        if not os.path.exists(self.users_file):
            # Create default admin user
            default_users = {
                "admin": {
                    "password_hash": self.hash_password("admin"),
                    "email": "admin@firevision.com",
                    "role": "admin",
                    "created_date": datetime.now().isoformat(),
                    "last_login": ""
                }
            }
            self.save_users(default_users)
        
        # Default cameras file
        if not os.path.exists(self.cameras_file):
            self.save_cameras({})
        
        # Default active streams file
        if not os.path.exists(self.streams_file):
            self.save_active_streams({})
    
    def hash_password(self, password: str) -> str:
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def verify_password(self, password: str, password_hash: str) -> bool:
        """Verify password against hash"""
        return self.hash_password(password) == password_hash
    
    # Configuration management
    def load_config(self) -> Dict:
        """Load application configuration"""
        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading config: {e}")
            return {}
    
    def sync_to_backend(self, file_type, data):
        """Send config data to backend Node.js server."""
        try:
            url = f"{self.BACKEND_URL}/{file_type}"
            resp = requests.post(url, json=data, timeout=3)
            if resp.status_code == 200:
                print(f"✅ Synced {file_type} to backend.")
            else:
                print(f"❌ Failed to sync {file_type}: {resp.text}")
        except Exception as e:
            print(f"❌ Error syncing {file_type} to backend: {e}")
    
    def save_config(self, config: Dict):
        """Save application configuration"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            self.sync_to_backend("app_config", config)
        except Exception as e:
            print(f"Error saving config: {e}")
    
    def update_config(self, key: str, value):
        """Update a specific configuration value"""
        config = self.load_config()
        keys = key.split('.')
        current = config
        
        # Navigate to the nested key
        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]
        
        # Set the value
        current[keys[-1]] = value
        self.save_config(config)
    
    def get_config(self, key: str, default=None):
        """Get a specific configuration value"""
        config = self.load_config()
        keys = key.split('.')
        current = config
        
        try:
            for k in keys:
                current = current[k]
            return current
        except KeyError:
            return default
    
    # User management
    def load_users(self) -> Dict:
        """Load users configuration"""
        try:
            with open(self.users_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading users: {e}")
            return {}
    
    def save_users(self, users: Dict):
        """Save users configuration"""
        try:
            with open(self.users_file, 'w') as f:
                json.dump(users, f, indent=4)
            self.sync_to_backend("users", users)
        except Exception as e:
            print(f"Error saving users: {e}")
    
    def sync_all_data_to_backend(self):
        """Send all configuration data to backend Node.js server upon login."""
        print("Initiating full data sync to backend...")
        self.sync_to_backend("app_config", self.load_config())
        self.sync_to_backend("users", self.load_users())
        self.sync_to_backend("cameras", self.load_cameras())
        self.sync_to_backend("active_streams", self.load_active_streams())
        print("Full data sync initiated.")

    def authenticate_user(self, username: str, password: str) -> bool:
        """Authenticate user credentials"""
        users = self.load_users()
        if username in users:
            stored_hash = users[username]["password_hash"]
            if self.verify_password(password, stored_hash):
                # Update last login
                users[username]["last_login"] = datetime.now().isoformat()
                self.save_users(users) # This already triggers sync_to_backend for users
                self.sync_all_data_to_backend() # Trigger full sync on successful login
                return True
        return False
    
    def create_user(self, username: str, password: str, email: str, role: str = "user") -> bool:
        """Create a new user"""
        users = self.load_users()
        if username in users:
            return False  # User already exists
        
        users[username] = {
            "password_hash": self.hash_password(password),
            "email": email,
            "role": role,
            "created_date": datetime.now().isoformat(),
            "last_login": ""
        }
        self.save_users(users)
        return True
    
    def save_login_details(self, username: str, remember: bool = True):
        """Save login details for auto-login"""
        if remember:
            self.update_config("last_login.username", username)
            self.update_config("last_login.remember", True)
            self.update_config("last_login.login_time", datetime.now().isoformat())
        else:
            self.update_config("last_login.username", "")
            self.update_config("last_login.remember", False)
    
    def get_saved_login(self) -> Optional[str]:
        """Get saved login username if remember is enabled"""
        if self.get_config("last_login.remember", False):
            return self.get_config("last_login.username", "")
        return None
    
    # Camera management
    def load_cameras(self) -> Dict:
        """Load cameras configuration"""
        try:
            with open(self.cameras_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading cameras: {e}")
            return {}
    
    def save_cameras(self, cameras: Dict):
        """Save cameras configuration"""
        try:
            with open(self.cameras_file, 'w') as f:
                json.dump(cameras, f, indent=4)
            self.sync_to_backend("cameras", cameras)
        except Exception as e:
            print(f"Error saving cameras: {e}")
    
    def add_camera(self, camera_id: str, camera_data: Dict, user_id: str = None):
        """Add a camera to persistent storage"""
        cameras = self.load_cameras()
        cameras[camera_id] = {
            **camera_data,
            "user_id": user_id,  # Add user ownership
            "added_date": datetime.now().isoformat(),
            "last_active": "",
            "detection_enabled": False,
            "auto_start": True,
            "stream_enabled": True
        }
        self.save_cameras(cameras)
    
    def update_camera(self, camera_id: str, updates: Dict):
        """Update camera configuration"""
        cameras = self.load_cameras()
        if camera_id in cameras:
            cameras[camera_id].update(updates)
            cameras[camera_id]["last_modified"] = datetime.now().isoformat()
            self.save_cameras(cameras)
    
    def remove_camera(self, camera_id: str):
        """Remove camera from persistent storage"""
        cameras = self.load_cameras()
        if camera_id in cameras:
            del cameras[camera_id]
            self.save_cameras(cameras)
    
    def get_camera(self, camera_id: str) -> Optional[Dict]:
        """Get camera configuration"""
        cameras = self.load_cameras()
        return cameras.get(camera_id)
    
    def get_cameras_by_user(self, user_id: str) -> List[Dict]:
        """Get all cameras belonging to a specific user"""
        cameras = self.load_cameras()
        user_cameras = []
        for camera_id, camera_data in cameras.items():
            if camera_data.get("user_id") == user_id:
                user_cameras.append({
                    "id": camera_id,
                    **camera_data
                })
        return user_cameras
    
    def get_camera_stats_by_user(self, user_id: str) -> Dict:
        """Get camera statistics for a specific user"""
        user_cameras = self.get_cameras_by_user(user_id)
        total_cameras = len(user_cameras)
        active_cameras = len([cam for cam in user_cameras if cam.get("status") == "active"])
        inactive_cameras = total_cameras - active_cameras
        
        return {
            "user_id": user_id,
            "total_cameras": total_cameras,
            "active_cameras": active_cameras,
            "inactive_cameras": inactive_cameras,
            "last_updated": datetime.now().isoformat()
        }
    
    def get_auto_start_cameras(self, user_id: str = None) -> List[Dict]:
        """Get cameras that should auto-start, optionally filtered by user"""
        cameras = self.load_cameras()
        auto_start_cameras = []
        for camera_id, camera_data in cameras.items():
            # Check if camera should auto-start
            if camera_data.get("auto_start", True):
                # If user_id is specified, only include cameras belonging to that user
                if user_id is None or camera_data.get("user_id") == user_id:
                    auto_start_cameras.append({
                        "id": camera_id,
                        **camera_data
                    })
        return auto_start_cameras
    
    # Active streams management
    def load_active_streams(self) -> Dict:
        """Load active streams configuration"""
        try:
            with open(self.streams_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading active streams: {e}")
            return {}
    
    def save_active_streams(self, streams: Dict):
        """Save active streams configuration"""
        try:
            with open(self.streams_file, 'w') as f:
                json.dump(streams, f, indent=4)
            self.sync_to_backend("active_streams", streams)
        except Exception as e:
            print(f"Error saving active streams: {e}")
    
    def add_active_stream(self, camera_id: str, stream_info: Dict):
        """Add an active stream"""
        streams = self.load_active_streams()
        streams[camera_id] = {
            **stream_info,
            "started_time": datetime.now().isoformat(),
            "status": "active"
        }
        self.save_active_streams(streams)
    
    def remove_active_stream(self, camera_id: str):
        """Remove an active stream"""
        streams = self.load_active_streams()
        if camera_id in streams:
            del streams[camera_id]
            self.save_active_streams(streams)
    
    def get_active_streams(self) -> Dict:
        """Get all active streams"""
        return self.load_active_streams()
    
    def should_auto_start_streams(self) -> bool:
        """Check if streams should auto-start"""
        return self.get_config("app_settings.auto_start_streaming", True)
    
    def should_auto_start_cameras(self) -> bool:
        """Check if cameras should auto-start"""
        return self.get_config("app_settings.auto_start_cameras", True)
