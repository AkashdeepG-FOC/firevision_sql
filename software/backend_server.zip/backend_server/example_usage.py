#!/usr/bin/env python3
"""
Example usage of the ConfigManager with user-camera association
"""

from config_manager import ConfigManager
import json

def main():
    # Initialize config manager
    config_manager = ConfigManager()
    
    # Create some example users
    print("Creating example users...")
    config_manager.create_user("admin", "admin123", "admin@firevision.com", "admin")
    config_manager.create_user("john", "john123", "john@example.com", "user")
    config_manager.create_user("sarah", "sarah123", "sarah@example.com", "user")
    
    # Add cameras for different users
    print("\nAdding cameras for different users...")
    
    # Admin's cameras
    config_manager.add_camera(
        "cam_admin_1", 
        {
            "name": "Admin Office Camera",
            "source": "rtsp://admin:pass@192.168.1.100:554/stream1",
            "type": "ip"
        },
        user_id="admin"
    )
    
    config_manager.add_camera(
        "cam_admin_2", 
        {
            "name": "Admin Lobby Camera",
            "source": "rtsp://admin:pass@192.168.1.101:554/stream1",
            "type": "ip"
        },
        user_id="admin"
    )
    
    # John's cameras
    config_manager.add_camera(
        "cam_john_1", 
        {
            "name": "John's Home Camera",
            "source": "rtsp://john:pass@192.168.1.200:554/stream1",
            "type": "ip"
        },
        user_id="john"
    )
    
    # Sarah's cameras
    config_manager.add_camera(
        "cam_sarah_1", 
        {
            "name": "Sarah's Office Camera",
            "source": "rtsp://sarah:pass@192.168.1.300:554/stream1",
            "type": "ip"
        },
        user_id="sarah"
    )
    
    config_manager.add_camera(
        "cam_sarah_2", 
        {
            "name": "Sarah's Warehouse Camera",
            "source": "rtsp://sarah:pass@192.168.1.301:554/stream1",
            "type": "ip"
        },
        user_id="sarah"
    )
    
    # Demonstrate getting cameras by user
    print("\n=== Camera Ownership Demo ===")
    
    # Get all cameras for admin
    admin_cameras = config_manager.get_cameras_by_user("admin")
    print(f"\nAdmin's cameras ({len(admin_cameras)}):")
    for cam in admin_cameras:
        print(f"  - {cam['name']} (ID: {cam['id']})")
    
    # Get all cameras for john
    john_cameras = config_manager.get_cameras_by_user("john")
    print(f"\nJohn's cameras ({len(john_cameras)}):")
    for cam in john_cameras:
        print(f"  - {cam['name']} (ID: {cam['id']})")
    
    # Get all cameras for sarah
    sarah_cameras = config_manager.get_cameras_by_user("sarah")
    print(f"\nSarah's cameras ({len(sarah_cameras)}):")
    for cam in sarah_cameras:
        print(f"  - {cam['name']} (ID: {cam['id']})")
    
    # Get camera statistics by user
    print("\n=== Camera Statistics by User ===")
    
    admin_stats = config_manager.get_camera_stats_by_user("admin")
    print(f"\nAdmin's camera stats:")
    print(f"  Total cameras: {admin_stats['total_cameras']}")
    print(f"  Active cameras: {admin_stats['active_cameras']}")
    print(f"  Inactive cameras: {admin_stats['inactive_cameras']}")
    
    john_stats = config_manager.get_camera_stats_by_user("john")
    print(f"\nJohn's camera stats:")
    print(f"  Total cameras: {john_stats['total_cameras']}")
    print(f"  Active cameras: {john_stats['active_cameras']}")
    print(f"  Inactive cameras: {john_stats['inactive_cameras']}")
    
    sarah_stats = config_manager.get_camera_stats_by_user("sarah")
    print(f"\nSarah's camera stats:")
    print(f"  Total cameras: {sarah_stats['total_cameras']}")
    print(f"  Active cameras: {sarah_stats['active_cameras']}")
    print(f"  Inactive cameras: {sarah_stats['inactive_cameras']}")
    
    # Demonstrate auto-start cameras filtered by user
    print("\n=== Auto-start Cameras by User ===")
    
    admin_auto_cameras = config_manager.get_auto_start_cameras(user_id="admin")
    print(f"\nAdmin's auto-start cameras ({len(admin_auto_cameras)}):")
    for cam in admin_auto_cameras:
        print(f"  - {cam['name']} (ID: {cam['id']})")
    
    # Show all cameras in the system
    print("\n=== All Cameras in System ===")
    all_cameras = config_manager.load_cameras()
    for camera_id, camera_data in all_cameras.items():
        owner = camera_data.get("user_id", "Unknown")
        print(f"  - {camera_data['name']} (ID: {camera_id}, Owner: {owner})")
    
    print("\n✅ Demo completed successfully!")
    print("📊 Data has been synced to the backend server")

if __name__ == "__main__":
    main() 