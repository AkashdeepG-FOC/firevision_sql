# User-Camera Association System

This document describes the user-camera association functionality that has been added to the surveillance system.

## Overview

The system now supports associating cameras with specific users, allowing for:
- User-specific camera management
- Access control based on ownership
- User-specific statistics and reporting
- Filtered camera operations by user

## Database Schema Changes

### Camera Schema Updates

The camera schema now includes a `user_id` field:

```javascript
const cameraSchema = new mongoose.Schema({
  camera_id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  source: { type: String, required: true },
  type: { type: String, default: "ip" },
  user_id: { type: String, required: true }, // NEW: Owner of the camera
  added_date: { type: String, required: true },
  // ... other fields
})
```

## API Endpoints

### New Endpoints

#### 1. Get Cameras by User
```
GET /api/config/cameras/user/:userId
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "camera_id": "cam_1",
      "name": "Office Camera",
      "source": "rtsp://...",
      "user_id": "admin",
      "status": "active",
      // ... other fields
    }
  ],
  "count": 1,
  "user_id": "admin"
}
```

#### 2. Get Camera Statistics by User
```
GET /api/config/cameras/stats/user/:userId
```

**Response:**
```json
{
  "success": true,
  "data": {
    "user_id": "admin",
    "total_cameras": 5,
    "active_cameras": 3,
    "inactive_cameras": 2,
    "last_updated": "2024-01-15T10:30:00.000Z"
  }
}
```

## ConfigManager Updates

### New Methods

#### 1. `add_camera(camera_id, camera_data, user_id=None)`
Add a camera with optional user association.

```python
config_manager.add_camera(
    "cam_1",
    {
        "name": "Office Camera",
        "source": "rtsp://192.168.1.100:554/stream1",
        "type": "ip"
    },
    user_id="admin"
)
```

#### 2. `get_cameras_by_user(user_id)`
Get all cameras belonging to a specific user.

```python
admin_cameras = config_manager.get_cameras_by_user("admin")
for camera in admin_cameras:
    print(f"Camera: {camera['name']}, ID: {camera['id']}")
```

#### 3. `get_camera_stats_by_user(user_id)`
Get camera statistics for a specific user.

```python
stats = config_manager.get_camera_stats_by_user("admin")
print(f"Total cameras: {stats['total_cameras']}")
print(f"Active cameras: {stats['active_cameras']}")
```

#### 4. `get_auto_start_cameras(user_id=None)`
Get auto-start cameras, optionally filtered by user.

```python
# Get all auto-start cameras
all_auto_cameras = config_manager.get_auto_start_cameras()

# Get only admin's auto-start cameras
admin_auto_cameras = config_manager.get_auto_start_cameras(user_id="admin")
```

## Usage Examples

### 1. Creating Users and Adding Cameras

```python
from config_manager import ConfigManager

config_manager = ConfigManager()

# Create users
config_manager.create_user("admin", "admin123", "admin@example.com", "admin")
config_manager.create_user("john", "john123", "john@example.com", "user")

# Add cameras for admin
config_manager.add_camera(
    "cam_admin_1",
    {"name": "Admin Office", "source": "rtsp://...", "type": "ip"},
    user_id="admin"
)

# Add cameras for john
config_manager.add_camera(
    "cam_john_1",
    {"name": "John's Home", "source": "rtsp://...", "type": "ip"},
    user_id="john"
)
```

### 2. Retrieving User-Specific Data

```python
# Get all cameras for a user
user_cameras = config_manager.get_cameras_by_user("admin")

# Get camera statistics
stats = config_manager.get_camera_stats_by_user("admin")

# Get auto-start cameras for a user
auto_cameras = config_manager.get_auto_start_cameras(user_id="admin")
```

### 3. Backend API Usage

```javascript
// Get cameras for a specific user
fetch('/api/config/cameras/user/admin')
  .then(response => response.json())
  .then(data => {
    console.log('Admin cameras:', data.data);
  });

// Get camera statistics for a user
fetch('/api/config/cameras/stats/user/admin')
  .then(response => response.json())
  .then(data => {
    console.log('Admin stats:', data.data);
  });
```

## Migration Notes

### For Existing Systems

If you have existing cameras without user association:

1. **Backward Compatibility**: The system maintains backward compatibility. Cameras without `user_id` will still work.

2. **Migration Strategy**: You can update existing cameras to associate them with users:

```python
# Update existing camera to associate with admin
config_manager.update_camera("existing_cam_id", {"user_id": "admin"})
```

3. **Default Behavior**: When no `user_id` is specified, cameras are created without ownership association.

## Security Considerations

1. **Access Control**: Implement proper authentication and authorization before exposing user-specific endpoints.

2. **Data Isolation**: Ensure users can only access their own cameras.

3. **Validation**: Validate user_id when adding or updating cameras.

## Testing

Run the example script to test the functionality:

```bash
cd backend_server
python example_usage.py
```

This will create sample users and cameras, then demonstrate all the new functionality.

## Future Enhancements

Potential future improvements:
- User roles and permissions for camera access
- Shared camera access between users
- Camera groups and organizations
- Advanced filtering and search capabilities
- Audit logs for camera ownership changes 