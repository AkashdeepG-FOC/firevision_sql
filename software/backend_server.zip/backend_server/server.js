const express = require("express")
const mongoose = require("mongoose")
const cors = require("cors")
const dotenv = require("dotenv")
const http = require("http")
const { Server } = require("socket.io")

// Load environment variables
dotenv.config()

const app = express()
const PORT = process.env.PORT || 5000
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://0.0.0.0/surveillance_db"

// Middleware
app.use(cors())
app.use(express.json({ limit: "50mb" }))
app.use(express.urlencoded({ extended: true, limit: "50mb" }))

// Logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`)
  next()
})

// Connect to MongoDB
mongoose
  .connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("✅ MongoDB connected successfully")
    console.log(`📊 Database: ${MONGODB_URI}`)
  })
  .catch((err) => {
    console.error("❌ MongoDB connection error:", err)
    process.exit(1)
  })

// Define Mongoose Schemas and Models

// App Configuration Schema
const appConfigSchema = new mongoose.Schema({
  app_settings: {
    auto_start_cameras: { type: Boolean, default: true },
    auto_start_streaming: { type: Boolean, default: true },
    remember_login: { type: Boolean, default: true },
    detection_confidence: { type: Number, default: 0.5 },
    stream_quality: { type: Number, default: 75 },
    stream_fps: { type: Number, default: 15 },
    recording_format: { type: String, default: "mp4" },
    auto_upload_to_drive: { type: Boolean, default: false },
    tray_notification_shown: { type: Boolean, default: false },
    close_notification_shown: { type: Boolean, default: false },
  },
  server_settings: {
    stream_server_url: { type: String, default: "http://localhost:3000" },
    auto_start_server: { type: Boolean, default: true },
  },
  last_login: {
    username: { type: String, default: "" },
    remember: { type: Boolean, default: false },
    login_time: { type: String, default: "" },
  },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
})

const AppConfig = mongoose.model("AppConfig", appConfigSchema)

// User Schema
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password_hash: { type: String, required: true },
  email: { type: String, required: true },
  role: { type: String, default: "user" },
  created_date: { type: String, required: true },
  last_login: { type: String, default: "" },
  is_active: { type: Boolean, default: true },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
})

const User = mongoose.model("User", userSchema)

// Camera Schema
const cameraSchema = new mongoose.Schema({
  camera_id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  source: { type: String, required: true },
  type: { type: String, default: "ip" }, // ip, usb, rtsp, etc.
  user_id: { type: String, required: true }, // Owner of the camera
  added_date: { type: String, required: true },
  last_active: { type: String, default: "" },
  last_modified: { type: String, default: "" },
  detection_enabled: { type: Boolean, default: false },
  auto_start: { type: Boolean, default: true },
  stream_enabled: { type: Boolean, default: true },
  people_detection_enabled: { type: Boolean, default: false },
  fire_smoke_detection_enabled: { type: Boolean, default: false },
  recording_enabled: { type: Boolean, default: false },
  status: { type: String, default: "inactive" }, // active, inactive, error
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
})

const Camera = mongoose.model("Camera", cameraSchema)

// Active Stream Schema
const activeStreamSchema = new mongoose.Schema({
  camera_id: { type: String, required: true, unique: true },
  stream_url: { type: String, default: "" },
  started_time: { type: String, required: true },
  status: { type: String, default: "active" }, // active, paused, stopped
  viewer_count: { type: Number, default: 0 },
  quality: { type: String, default: "medium" },
  fps: { type: Number, default: 15 },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
})

const ActiveStream = mongoose.model("ActiveStream", activeStreamSchema)

// System Log Schema for tracking sync operations
const systemLogSchema = new mongoose.Schema({
  operation: { type: String, required: true },
  data_type: { type: String, required: true },
  status: { type: String, required: true }, // success, error
  message: { type: String, default: "" },
  timestamp: { type: Date, default: Date.now },
  ip_address: { type: String, default: "" },
})

const SystemLog = mongoose.model("SystemLog", systemLogSchema)

// Fire Detection Alert Schema
const fireDetectionSchema = new mongoose.Schema({
  alert_id: { type: String, required: true, unique: true },
  camera_id: { type: String, required: true },
  camera_name: { type: String, required: true },
  detection_type: { type: String, required: true }, // 'fire', 'smoke', 'combined'
  confidence: { type: Number, required: true },
  frame_data: { type: String, required: true }, // Base64 encoded image
  detections: [{
    bbox: { type: [Number], required: true }, // [x1, y1, x2, y2]
    confidence: { type: Number, required: true },
    type: { type: String, required: true }, // 'fire' or 'smoke'
    center: { type: [Number], required: true } // [center_x, center_y]
  }],
  alert_info: {
    fire_count: { type: Number, default: 0 },
    smoke_count: { type: Number, default: 0 },
    max_confidence: { type: Number, default: 0 },
    alert_type: { type: String, default: '' }
  },
  status: { 
    type: String, 
    required: true, 
    enum: ['pending', 'dispatched', 'false_alarm', 'resolved'],
    default: 'pending'
  },
  user_id: { type: String, required: true }, // User who created the alert
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
  resolved_at: { type: Date },
  resolved_by: { type: String }, // User who resolved the alert
  resolution_notes: { type: String },
  dispatch_time: { type: Date },
  dispatch_notes: { type: String }
})

const FireDetection = mongoose.model("FireDetection", fireDetectionSchema)

// Helper function to log operations
async function logOperation(operation, dataType, status, message = "", ipAddress = "") {
  try {
    await SystemLog.create({
      operation,
      data_type: dataType,
      status,
      message,
      ip_address: ipAddress,
    })
  } catch (error) {
    console.error("Error logging operation:", error)
  }
}

// API Routes

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "OK",
    timestamp: new Date().toISOString(),
    mongodb: mongoose.connection.readyState === 1 ? "Connected" : "Disconnected",
  })
})

// App Configuration endpoint
app.post("/api/config/app_config", async (req, res) => {
  try {
    const configData = req.body
    console.log("📋 Received app config data:", Object.keys(configData))

    // Add timestamp
    configData.updated_at = new Date()

    // Upsert the app config (there should only be one)
    const result = await AppConfig.findOneAndUpdate(
      {}, // Find any document (there should be only one)
      { $set: configData },
      { upsert: true, new: true, runValidators: true },
    )

    await logOperation("sync", "app_config", "success", "App config synced successfully", req.ip)
    console.log("✅ App config synced successfully")

    res.status(200).json({
      success: true,
      message: "App config synced successfully",
      data: result,
    })
  } catch (error) {
    console.error("❌ Error syncing app config:", error)
    await logOperation("sync", "app_config", "error", error.message, req.ip)
    res.status(500).json({
      success: false,
      message: "Failed to sync app config",
      error: error.message,
    })
  }
})

// Users endpoint
app.post("/api/config/users", async (req, res) => {
  try {
    const usersData = req.body
    console.log("👥 Received users data:", Object.keys(usersData).length, "users")

    let syncedCount = 0
    const errors = []

    for (const username in usersData) {
      if (Object.hasOwnProperty.call(usersData, username)) {
        try {
          const userData = usersData[username]
          userData.username = username
          userData.updated_at = new Date()

          await User.findOneAndUpdate(
            { username: username },
            { $set: userData },
            { upsert: true, new: true, runValidators: true },
          )
          syncedCount++
        } catch (userError) {
          console.error(`❌ Error syncing user ${username}:`, userError)
          errors.push({ username, error: userError.message })
        }
      }
    }

    await logOperation("sync", "users", "success", `${syncedCount} users synced`, req.ip)
    console.log(`✅ Users synced: ${syncedCount}/${Object.keys(usersData).length}`)

    res.status(200).json({
      success: true,
      message: `Users synced successfully: ${syncedCount}/${Object.keys(usersData).length}`,
      synced_count: syncedCount,
      total_count: Object.keys(usersData).length,
      errors: errors,
    })
  } catch (error) {
    console.error("❌ Error syncing users:", error)
    await logOperation("sync", "users", "error", error.message, req.ip)
    res.status(500).json({
      success: false,
      message: "Failed to sync users",
      error: error.message,
    })
  }
})

// Cameras endpoint
app.post("/api/config/cameras", async (req, res) => {
  try {
    const camerasData = req.body
    console.log("📹 Received cameras data:", Object.keys(camerasData).length, "cameras")

    let syncedCount = 0
    const errors = []

    for (const cameraId in camerasData) {
      if (Object.hasOwnProperty.call(camerasData, cameraId)) {
        try {
          const cameraData = camerasData[cameraId]
          cameraData.camera_id = cameraId
          cameraData.updated_at = new Date()

          await Camera.findOneAndUpdate(
            { camera_id: cameraId },
            { $set: cameraData },
            { upsert: true, new: true, runValidators: true },
          )
          syncedCount++
        } catch (cameraError) {
          console.error(`❌ Error syncing camera ${cameraId}:`, cameraError)
          errors.push({ camera_id: cameraId, error: cameraError.message })
        }
      }
    }

    await logOperation("sync", "cameras", "success", `${syncedCount} cameras synced`, req.ip)
    console.log(`✅ Cameras synced: ${syncedCount}/${Object.keys(camerasData).length}`)

    res.status(200).json({
      success: true,
      message: `Cameras synced successfully: ${syncedCount}/${Object.keys(camerasData).length}`,
      synced_count: syncedCount,
      total_count: Object.keys(camerasData).length,
      errors: errors,
    })
  } catch (error) {
    console.error("❌ Error syncing cameras:", error)
    await logOperation("sync", "cameras", "error", error.message, req.ip)
    res.status(500).json({
      success: false,
      message: "Failed to sync cameras",
      error: error.message,
    })
  }
})

// Active Streams endpoint
app.post("/api/config/active_streams", async (req, res) => {
  try {
    const streamsData = req.body
    console.log("🎥 Received active streams data:", Object.keys(streamsData).length, "streams")

    // Clear all existing active streams first
    await ActiveStream.deleteMany({})

    let syncedCount = 0
    const errors = []

    for (const cameraId in streamsData) {
      if (Object.hasOwnProperty.call(streamsData, cameraId)) {
        try {
          const streamData = streamsData[cameraId]
          streamData.camera_id = cameraId
          streamData.updated_at = new Date()

          await ActiveStream.create(streamData)
          syncedCount++
        } catch (streamError) {
          console.error(`❌ Error syncing stream ${cameraId}:`, streamError)
          errors.push({ camera_id: cameraId, error: streamError.message })
        }
      }
    }

    await logOperation("sync", "active_streams", "success", `${syncedCount} streams synced`, req.ip)
    console.log(`✅ Active streams synced: ${syncedCount}/${Object.keys(streamsData).length}`)

    res.status(200).json({
      success: true,
      message: `Active streams synced successfully: ${syncedCount}/${Object.keys(streamsData).length}`,
      synced_count: syncedCount,
      total_count: Object.keys(streamsData).length,
      errors: errors,
    })
  } catch (error) {
    console.error("❌ Error syncing active streams:", error)
    await logOperation("sync", "active_streams", "error", error.message, req.ip)
    res.status(500).json({
      success: false,
      message: "Failed to sync active streams",
      error: error.message,
    })
  }
})

// GET endpoints to retrieve data

// Get app config
app.get("/api/config/app_config", async (req, res) => {
  try {
    const config = await AppConfig.findOne()
    res.json({
      success: true,
      data: config,
    })
  } catch (error) {
    console.error("Error fetching app config:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch app config",
      error: error.message,
    })
  }
})

// Get all users
app.get("/api/config/users", async (req, res) => {
  try {
    const users = await User.find({}, { password_hash: 0 }) // Exclude password hash
    res.json({
      success: true,
      data: users,
      count: users.length,
    })
  } catch (error) {
    console.error("Error fetching users:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch users",
      error: error.message,
    })
  }
})

// Get all cameras
app.get("/api/config/cameras", async (req, res) => {
  try {
    const cameras = await Camera.find()
    res.json({
      success: true,
      data: cameras,
      count: cameras.length,
    })
  } catch (error) {
    console.error("Error fetching cameras:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch cameras",
      error: error.message,
    })
  }
})

// Get cameras by user
app.get("/api/config/cameras/user/:userId", async (req, res) => {
  try {
    const { userId } = req.params
    let cameras = await Camera.find({ user_id: userId })

    // For testing: if no cameras are found, add a default one with RTSP details
    if (cameras.length === 0) {
      cameras = [
        {
          camera_id: "default-cam-1",
          user_id: userId,
          name: "Default Test Camera",
          source: "rtsp://focadmin:Abcd123@192.168.1.18:554/stream1",
          status: "active",
          location: "Test Area",
          description: "A default camera added for testing purposes.",
          created_at: new Date(),
          updated_at: new Date(),
        },
      ]
    }

    res.json({
      success: true,
      data: cameras,
      count: cameras.length,
      user_id: userId,
    })
  } catch (error) {
    console.error("Error fetching cameras for user:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch cameras for user",
      error: error.message,
    })
  }
})

// Get camera statistics by user
app.get("/api/config/cameras/stats/user/:userId", async (req, res) => {
  try {
    const { userId } = req.params
    const [totalCameras, activeCameras, inactiveCameras] = await Promise.all([
      Camera.countDocuments({ user_id: userId }),
      Camera.countDocuments({ user_id: userId, status: "active" }),
      Camera.countDocuments({ user_id: userId, status: "inactive" }),
    ])

    res.json({
      success: true,
      data: {
        user_id: userId,
        total_cameras: totalCameras,
        active_cameras: activeCameras,
        inactive_cameras: inactiveCameras,
        last_updated: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error("Error fetching camera stats for user:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch camera stats for user",
      error: error.message,
    })
  }
})

// Get active streams
app.get("/api/config/active_streams", async (req, res) => {
  try {
    const streams = await ActiveStream.find()
    res.json({
      success: true,
      data: streams,
      count: streams.length,
    })
  } catch (error) {
    console.error("Error fetching active streams:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch active streams",
      error: error.message,
    })
  }
})

// Get system logs
app.get("/api/logs", async (req, res) => {
  try {
    const limit = Number.parseInt(req.query.limit) || 100
    const logs = await SystemLog.find().sort({ timestamp: -1 }).limit(limit)

    res.json({
      success: true,
      data: logs,
      count: logs.length,
    })
  } catch (error) {
    console.error("Error fetching logs:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch logs",
      error: error.message,
    })
  }
})

// Get system statistics
app.get("/api/stats", async (req, res) => {
  try {
    const [userCount, cameraCount, activeStreamCount, logCount] = await Promise.all([
      User.countDocuments(),
      Camera.countDocuments(),
      ActiveStream.countDocuments(),
      SystemLog.countDocuments(),
    ])

    const activeCameras = await Camera.countDocuments({ status: "active" })
    const recentLogs = await SystemLog.countDocuments({
      timestamp: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
    })

    res.json({
      success: true,
      data: {
        users: userCount,
        cameras: cameraCount,
        active_cameras: activeCameras,
        active_streams: activeStreamCount,
        total_logs: logCount,
        recent_logs_24h: recentLogs,
        last_updated: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error("Error fetching stats:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch statistics",
      error: error.message,
    })
  }
})

// ===== FIRE DETECTION API ENDPOINTS =====

// Create fire detection alert
app.post("/api/fire-detection/alert", async (req, res) => {
  try {
    const {
      camera_id,
      camera_name,
      detection_type,
      confidence,
      frame_data,
      detections,
      alert_info,
      user_id
    } = req.body

    console.log(`🔥 Received fire detection alert for camera ${camera_id}`)

    // Validate required fields
    if (!camera_id || !camera_name || !detection_type || !frame_data || !user_id) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
        required: ["camera_id", "camera_name", "detection_type", "frame_data", "user_id"]
      })
    }

    // Generate unique alert ID
    const alert_id = `fire_${camera_id}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

    // Create fire detection alert
    const fireAlert = await FireDetection.create({
      alert_id,
      camera_id,
      camera_name,
      detection_type,
      confidence: confidence || 0,
      frame_data,
      detections: detections || [],
      alert_info: alert_info || {},
      user_id,
      status: 'pending'
    })

    await logOperation("fire_alert", "fire_detection", "success", 
      `Fire alert created for camera ${camera_id}`, req.ip)

    console.log(`✅ Fire detection alert created: ${alert_id}`)

    // Emit fire_alert event to all connected clients
    io.emit("fire_alert", {
      alert_id: fireAlert.alert_id,
      camera_id,
      camera_name,
      detection_type,
      confidence,
      frame_data, // base64 image
      detections,
      alert_info,
      user_id: fireAlert.user_id,
      created_at: fireAlert.created_at
    });

    res.status(201).json({
      success: true,
      message: "Fire detection alert created successfully",
      data: {
        alert_id: fireAlert.alert_id,
        status: fireAlert.status,
        created_at: fireAlert.created_at
      }
    })

  } catch (error) {
    console.error("❌ Error creating fire detection alert:", error)
    await logOperation("fire_alert", "fire_detection", "error", error.message, req.ip)
    res.status(500).json({
      success: false,
      message: "Failed to create fire detection alert",
      error: error.message
    })
  }
})

// Get fire detection alerts
app.get("/api/fire-detection/alerts", async (req, res) => {
  try {
    const { status, camera_id, limit = 50, page = 1 } = req.query
    
    const query = {}
    if (status) query.status = status
    if (camera_id) query.camera_id = camera_id

    const skip = (parseInt(page) - 1) * parseInt(limit)
    
    const [alerts, total] = await Promise.all([
      FireDetection.find(query)
        .sort({ created_at: -1 })
        .skip(skip)
        .limit(parseInt(limit)),
      FireDetection.countDocuments(query)
    ])

    res.json({
      success: true,
      data: alerts,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    })

  } catch (error) {
    console.error("Error fetching fire detection alerts:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch fire detection alerts",
      error: error.message
    })
  }
})

// Get specific fire detection alert
app.get("/api/fire-detection/alerts/:alertId", async (req, res) => {
  try {
    const { alertId } = req.params
    
    const alert = await FireDetection.findOne({ alert_id: alertId })
    
    if (!alert) {
      return res.status(404).json({
        success: false,
        message: "Fire detection alert not found"
      })
    }

    res.json({
      success: true,
      data: alert
    })

  } catch (error) {
    console.error("Error fetching fire detection alert:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch fire detection alert",
      error: error.message
    })
  }
})

// Mark fire detection as false alarm
app.put("/api/fire-detection/alerts/:alertId/false-alarm", async (req, res) => {
  try {
    const { alertId } = req.params
    const { resolved_by, resolution_notes } = req.body

    console.log(`❌ Marking fire alert ${alertId} as false alarm`)

    const alert = await FireDetection.findOne({ alert_id: alertId })
    
    if (!alert) {
      return res.status(404).json({
        success: false,
        message: "Fire detection alert not found"
      })
    }

    if (alert.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: "Alert cannot be marked as false alarm - already processed"
      })
    }

    // Update alert status
    alert.status = 'false_alarm'
    alert.resolved_at = new Date()
    alert.resolved_by = resolved_by || 'system'
    alert.resolution_notes = resolution_notes || 'Marked as false alarm by user'
    alert.updated_at = new Date()

    await alert.save()

    await logOperation("false_alarm", "fire_detection", "success", 
      `Fire alert ${alertId} marked as false alarm`, req.ip)

    console.log(`✅ Fire alert ${alertId} marked as false alarm`)

    res.json({
      success: true,
      message: "Fire detection alert marked as false alarm",
      data: {
        alert_id: alert.alert_id,
        status: alert.status,
        resolved_at: alert.resolved_at
      }
    })

  } catch (error) {
    console.error("❌ Error marking fire alert as false alarm:", error)
    await logOperation("false_alarm", "fire_detection", "error", error.message, req.ip)
    res.status(500).json({
      success: false,
      message: "Failed to mark fire alert as false alarm",
      error: error.message
    })
  }
})

// Dispatch emergency services for fire detection
app.put("/api/fire-detection/alerts/:alertId/dispatch", async (req, res) => {
  try {
    const { alertId } = req.params
    const { dispatched_by, dispatch_notes } = req.body

    console.log(`🚨 Dispatching emergency services for fire alert ${alertId}`)

    const alert = await FireDetection.findOne({ alert_id: alertId })
    
    if (!alert) {
      return res.status(404).json({
        success: false,
        message: "Fire detection alert not found"
      })
    }

    if (alert.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: "Alert cannot be dispatched - already processed"
      })
    }

    // Update alert status
    alert.status = 'dispatched'
    alert.dispatch_time = new Date()
    alert.resolved_by = dispatched_by || 'system'
    alert.dispatch_notes = dispatch_notes || 'Emergency services dispatched'
    alert.updated_at = new Date()

    await alert.save()

    await logOperation("dispatch", "fire_detection", "success", 
      `Emergency services dispatched for fire alert ${alertId}`, req.ip)

    console.log(`✅ Emergency services dispatched for fire alert ${alertId}`)

    res.json({
      success: true,
      message: "Emergency services dispatched successfully",
      data: {
        alert_id: alert.alert_id,
        status: alert.status,
        dispatch_time: alert.dispatch_time
      }
    })

  } catch (error) {
    console.error("❌ Error dispatching emergency services:", error)
    await logOperation("dispatch", "fire_detection", "error", error.message, req.ip)
    res.status(500).json({
      success: false,
      message: "Failed to dispatch emergency services",
      error: error.message
    })
  }
})

// Resolve fire detection alert
app.put("/api/fire-detection/alerts/:alertId/resolve", async (req, res) => {
  try {
    const { alertId } = req.params
    const { resolved_by, resolution_notes } = req.body

    console.log(`✅ Resolving fire alert ${alertId}`)

    const alert = await FireDetection.findOne({ alert_id: alertId })
    
    if (!alert) {
      return res.status(404).json({
        success: false,
        message: "Fire detection alert not found"
      })
    }

    if (alert.status === 'resolved') {
      return res.status(400).json({
        success: false,
        message: "Alert is already resolved"
      })
    }

    // Update alert status
    alert.status = 'resolved'
    alert.resolved_at = new Date()
    alert.resolved_by = resolved_by || 'system'
    alert.resolution_notes = resolution_notes || 'Alert resolved by user'
    alert.updated_at = new Date()

    await alert.save()

    await logOperation("resolve", "fire_detection", "success", 
      `Fire alert ${alertId} resolved`, req.ip)

    console.log(`✅ Fire alert ${alertId} resolved`)

    res.json({
      success: true,
      message: "Fire detection alert resolved successfully",
      data: {
        alert_id: alert.alert_id,
        status: alert.status,
        resolved_at: alert.resolved_at
      }
    })

  } catch (error) {
    console.error("❌ Error resolving fire alert:", error)
    await logOperation("resolve", "fire_detection", "error", error.message, req.ip)
    res.status(500).json({
      success: false,
      message: "Failed to resolve fire alert",
      error: error.message
    })
  }
})

// Get fire detection statistics
app.get("/api/fire-detection/stats", async (req, res) => {
  try {
    const { camera_id, days = 30 } = req.query
    
    const query = {}
    if (camera_id) query.camera_id = camera_id
    
    // Add date filter for last N days
    const dateFilter = new Date()
    dateFilter.setDate(dateFilter.getDate() - parseInt(days))
    query.created_at = { $gte: dateFilter }

    const [totalAlerts, pendingAlerts, dispatchedAlerts, falseAlarms, resolvedAlerts] = await Promise.all([
      FireDetection.countDocuments(query),
      FireDetection.countDocuments({ ...query, status: 'pending' }),
      FireDetection.countDocuments({ ...query, status: 'dispatched' }),
      FireDetection.countDocuments({ ...query, status: 'false_alarm' }),
      FireDetection.countDocuments({ ...query, status: 'resolved' })
    ])

    // Get alerts by detection type
    const fireAlerts = await FireDetection.countDocuments({ ...query, detection_type: 'fire' })
    const smokeAlerts = await FireDetection.countDocuments({ ...query, detection_type: 'smoke' })
    const combinedAlerts = await FireDetection.countDocuments({ ...query, detection_type: 'combined' })

    res.json({
      success: true,
      data: {
        period_days: parseInt(days),
        total_alerts: totalAlerts,
        pending_alerts: pendingAlerts,
        dispatched_alerts: dispatchedAlerts,
        false_alarms: falseAlarms,
        resolved_alerts: resolvedAlerts,
        by_detection_type: {
          fire: fireAlerts,
          smoke: smokeAlerts,
          combined: combinedAlerts
        },
        last_updated: new Date().toISOString()
      }
    })

  } catch (error) {
    console.error("Error fetching fire detection statistics:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch fire detection statistics",
      error: error.message
    })
  }
})

// Error handling middleware
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err)
  res.status(500).json({
    success: false,
    message: "Internal server error",
    error: process.env.NODE_ENV === "development" ? err.message : "Something went wrong",
  })
})

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({
    success: false,
    message: "Endpoint not found",
    path: req.originalUrl,
  })
})

// Graceful shutdown
process.on("SIGINT", async () => {
  console.log("\n🛑 Shutting down server...")
  try {
    await mongoose.connection.close()
    console.log("✅ MongoDB connection closed")
    process.exit(0)
  } catch (error) {
    console.error("❌ Error during shutdown:", error)
    process.exit(1)
  }
})

// Start the server
const server = http.createServer(app)
const io = new Server(server, {
  cors: { origin: "*" }
})

// When a client connects
io.on("connection", (socket) => {
  console.log("Admin dashboard connected:", socket.id)
})

server.listen(PORT, () => {
  console.log("🚀 Surveillance Backend Server Started")
  console.log(`📡 Server running on port ${PORT}`)
  console.log(`🌐 Health check: http://localhost:${PORT}/api/health`)
  console.log(`📊 Statistics: http://localhost:${PORT}/api/stats`)
  console.log("⏰ Server started at:", new Date().toISOString())
})
