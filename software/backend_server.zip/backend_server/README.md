# Surveillance Backend Server

Node.js backend server for Fire Vision Pro surveillance system with MongoDB integration.

## Features

- ✅ Receive and store configuration data from Python client
- ✅ MongoDB integration with Mongoose ODM
- ✅ RESTful API endpoints
- ✅ System logging and statistics
- ✅ Error handling and validation
- ✅ Health check endpoints

## Installation

1. **Clone or create the project directory:**
   \`\`\`bash
   mkdir surveillance-backend
   cd surveillance-backend
   \`\`\`

2. **Install dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

3. **Setup environment variables:**
   \`\`\`bash
   cp .env.example .env
   # Edit .env file with your MongoDB connection string
   \`\`\`

4. **Start MongoDB:**
   - Local: Make sure MongoDB is running on your system
   - Cloud: Use MongoDB Atlas connection string in .env

5. **Start the server:**
   \`\`\`bash
   # Production
   npm start
   
   # Development (with auto-restart)
   npm run dev
   \`\`\`

## API Endpoints

### Configuration Sync (POST)
- `POST /api/config/app_config` - Sync app configuration
- `POST /api/config/users` - Sync user data
- `POST /api/config/cameras` - Sync camera configurations
- `POST /api/config/active_streams` - Sync active stream data

### Data Retrieval (GET)
- `GET /api/config/app_config` - Get app configuration
- `GET /api/config/users` - Get all users
- `GET /api/config/cameras` - Get all cameras
- `GET /api/config/active_streams` - Get active streams

### System Endpoints
- `GET /api/health` - Health check
- `GET /api/stats` - System statistics
- `GET /api/logs` - System logs

## Database Schema

### Collections:
- `appconfigs` - Application configuration
- `users` - User accounts and authentication
- `cameras` - Camera configurations
- `activestreams` - Currently active streams
- `systemlogs` - Operation logs

## Environment Variables

- `MONGODB_URI` - MongoDB connection string
- `PORT` - Server port (default: 5000)
- `NODE_ENV` - Environment (development/production)

## Usage with Python Client

The Python `ConfigManager` will automatically sync data to this server when users log in. Make sure the `BACKEND_URL` in your Python code matches your server address:

```python
BACKEND_URL = "http://localhost:5000/api/config"

```

## Real-Time Fire Alert Admin Dashboard

This backend now supports real-time fire alert notifications using WebSockets (socket.io). When a fire is detected, the backend will instantly send the alert (including the frame image) to all connected admin dashboards.

### How to Use the Admin Dashboard

1. **Start the backend server:**
   - Make sure you have installed dependencies:
     ```sh
     npm install
     ```
   - Start the server:
     ```sh
     node server.js
     ```

2. **Open the Admin Dashboard:**
   - Use the provided `admin_dashboard.html` file (see below) or create your own.
   - Open the HTML file in your browser (Chrome/Edge/Firefox).
   - The dashboard will connect to the backend and display fire alerts in real time, including the frame image.

### Example Admin Dashboard

Save the following as `admin_dashboard.html` and open it in your browser:

```html
<!DOCTYPE html>
<html>
<head>
  <title>Fire Detection Admin Dashboard</title>
  <script src="https://cdn.socket.io/4.7.4/socket.io.min.js"></script>
  <style>
    body { background: #181818; color: #fff; font-family: Arial; }
    .alert { border: 2px solid #ff3333; margin: 20px; padding: 20px; border-radius: 10px; background: #222; }
    img { max-width: 400px; border: 1px solid #444; }
  </style>
</head>
<body>
  <h1>🔥 Fire Detection Alerts (Real-Time)</h1>
  <div id="alerts"></div>
  <script>
    const socket = io("http://localhost:5000"); // Change if backend is on another host/port

    socket.on("connect", () => {
      console.log("Connected to backend for fire alerts");
    });

    socket.on("fire_alert", (data) => {
      const div = document.createElement("div");
      div.className = "alert";
      div.innerHTML = `
        <h2>🚨 Fire Detected!</h2>
        <b>Camera:</b> ${data.camera_name} <br>
        <b>Type:</b> ${data.detection_type} <br>
        <b>Confidence:</b> ${data.confidence} <br>
        <b>Time:</b> ${new Date(data.created_at).toLocaleString()} <br>
        <img src="data:image/jpeg;base64,${data.frame_data}" alt="Fire Frame" />
      `;
      document.getElementById("alerts").prepend(div);
    });
  </script>
</body>
</html>
```

---

- The dashboard will show each fire alert as soon as it is detected, with the frame image and details.
- You can open the dashboard on multiple devices/browsers for multi-admin monitoring.
